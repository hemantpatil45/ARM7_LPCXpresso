#include <stdint.h>
#include <stdbool.h>
#include "LPC24xx.h"
#include "glcd.h"
#include "system_init.h"
#include "ethernet.h"
#include "ethernet_tx.h"

void Delay1Sec(void)
{
    volatile uint32_t i;
    for(i = 0; i < 120000; i++) {
        __asm("NOP");
    }
}
void Delay2Sec(void)
{
    volatile uint32_t i;
    for(i = 0; i < 1200000; i++) {
        __asm("NOP");
    }
}

int main(void)
{
    bool link_status;
    uint32_t tx_counter = 0;

    /* Standard Raw Ethernet Broadcast Frame */
    // Force the array to be exactly 64 bytes
    uint8_t broadcast_frame[64] = {
        /* Dest MAC (6) + Src MAC (6) + Type (2) = 14 bytes */
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
        0x00, 0x11, 0x22, 0x33, 0x44, 0x55,
        0x88, 0xB5,

        /* Payload (HELLO-AKADEMIKA is 15 bytes) */
        'H', 'E', 'L', 'L', 'O', '-',  'V', 'I', 'J', 'A', 'Y', 'A', ' ', ' ', ' '

        /* The compiler will automatically set the rest to 0x00 */
    };

    PLL_Init();
    system_Init();
    GLCD_Init();
    GLCD_Clear();
    Timer0_init();
    SW2_Keypad_Init();
    GLCD_RowWriteMargin(0,"WELCOME TO AKADEMIKA");
    GLCD_RowWriteMargin(2,"PL-ARM7 Ethernet-Tx ");
    GLCD_RowWriteMargin(4,"PESS SW2 For Init   ");
    while(SW2_Pressed()==0){
      }
    GLCD_RowWriteMargin(4,"                    ");
    /* Initializes MAC, PHY, and routing. Returns true if Link is negotiated. */
    link_status = Eth_Init();

    if (link_status) {
        GLCD_RowWriteMargin(0, "Link Status: UP   ");
    } else {
        GLCD_RowWriteMargin(0, "Link Status: FAIL ");
    }
    GLCD_RowWriteMargin(2,"WAIT 10             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 09             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 08             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 07             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 06             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 05             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 04             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 03             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 02             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 01             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"WAIT 00             ");
    Delay2Sec();
    GLCD_RowWriteMargin(2,"PRESS SW2 To send Tx");
 uint8_t armed=1;
 while(armed == 1) {
         /* Check if the button is currently being held down */
         if (SW2_Pressed()) {

             GLCD_RowWriteMargin(6, "Transmitting...     ");

             /* While the button IS held, keep sending data */
             while(SW2_Pressed()) {
                 if (link_status) {
                     if (EMAC_SendPacket(broadcast_frame, sizeof(broadcast_frame))) {
                         tx_counter++;

                         /* Prepare and display the payload on one line */
                         char display_payload[21] = {0};
                         memcpy(display_payload, &broadcast_frame[14], 15);
                         GLCD_RowWriteMargin(6, display_payload);
                     }
                 }

                 /* Define the speed of continuous transmission */
                 Delay1Sec();
             }

             GLCD_RowWriteMargin(6, "Stopped.            ");
         }
     }
}
