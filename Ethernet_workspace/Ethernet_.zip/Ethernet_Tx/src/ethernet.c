#include "ethernet.h"
#include "ethernet_reg.h"
#include "ethernet_tx.h"
/* #include "ethernet_rx.h" */

#define PCONP           (*((volatile uint32_t *)0xE01FC0C4))
#define PINSEL2         (*((volatile uint32_t *)0xE002C008))
#define PINSEL3         (*((volatile uint32_t *)0xE002C00C))

static void Eth_InitPins(void)
{
    /* Enable power to Ethernet Block */
    PCONP |= (1 << 30);

    /*
     * CORRECTED PINSEL2: Controls P1.0 to P1.15
     * Routes: TXD0(P1.0), TXD1(P1.1), TX_EN(P1.4), CRS(P1.8),
     *         RXD0(P1.9), RXD1(P1.10), RX_ER(P1.14), and crucially REF_CLK(P1.15)
     *
     * Mask ~0xF03F030F clears the necessary bits.
     * Mask  0x50150105 sets them to Alternate Function 1 (RMII).
     */
    PINSEL2 = (PINSEL2 & ~0xF03F030F) | 0x50150105;

    /*
     * CORRECTED PINSEL3: Controls P1.16 to P1.31
     * Routes only MDC(P1.16) and MDIO(P1.17).
     *
     * Mask ~0x0000000F clears the bottom 4 bits.
     * Mask  0x00000005 sets them to Alternate Function 1.
     */
    PINSEL3 = (PINSEL3 & ~0x0000000F) | 0x00000005;
}

void Eth_WritePHY(uint32_t PhyReg, uint16_t Value)
{
    LPC_EMAC->MCMD = 0;
    LPC_EMAC->MADR = DP83848_DEF_ADR | PhyReg;
    LPC_EMAC->MWTD = Value;
    while ((LPC_EMAC->MIND & 1) != 0);
}

uint16_t Eth_ReadPHY(uint32_t PhyReg)
{
    LPC_EMAC->MADR = DP83848_DEF_ADR | PhyReg;
    LPC_EMAC->MCMD = 1;
    while ((LPC_EMAC->MIND & 1) != 0);
    LPC_EMAC->MCMD = 0;
    return (uint16_t)(LPC_EMAC->MRDD & 0xFFFF);
}

bool Eth_Init(void)
{
    uint32_t timeout;
    uint16_t phyStatus;

    /* 1. Hardware Pin Setup */
    Eth_InitPins();

    /* 2. Soft Reset the MAC */
    LPC_EMAC->MAC1    = MAC1_RES_TX | MAC1_RES_MCS_TX | MAC1_RES_RX | MAC1_RES_MCS_RX | MAC1_SIM_RES | MAC1_SOFT_RES;
    LPC_EMAC->COMMAND = CR_REG_RES | CR_TX_RES | CR_RX_RES | CR_PASS_RUNT_FRM;
    for (timeout = 100; timeout; timeout--);

    /* 3. Configure MAC for RMII */
    LPC_EMAC->MAC1 = MAC1_PASS_ALL;
    LPC_EMAC->COMMAND = CR_RMII | CR_PASS_RUNT_FRM;
    LPC_EMAC->MCFG = 0x0018; /* Set MDC clock divider */
    LPC_EMAC->MAC2 = MAC2_CRC_EN | MAC2_PAD_EN;
    LPC_EMAC->MAXF = 1536;
    LPC_EMAC->CLRT = 0x370F;
    LPC_EMAC->IPGR = 0x0C12;
    LPC_EMAC->IPGT = 0x0015;

    /* ==================================================================== */
    /* 4. RESET PHY: Clears everything back to the MII hardware strap state */
    /* ==================================================================== */
    Eth_WritePHY(DP83848_BMCR, PHY_BMCR_RESET);
    for (timeout = 0; timeout < 0xFFFFF; timeout++) {
        if ((Eth_ReadPHY(DP83848_BMCR) & PHY_BMCR_RESET) == 0) break;
    }

    /* ==================================================================== */
    /* 5. OVERRIDE HARDWARE STRAP: Force RMII Mode so it stays active!      */
    /* Register 0x17 is the RMII and Bypass Register (RBR)                  */
    /* Bit 5 (0x20) enables RMII mode, overriding the physical pull-up      */
    /* ==================================================================== */
    Eth_WritePHY(0x17, (1 << 5));

    /* ==================================================================== */
    /* 6. AUTO-NEGOTIATE: Establish the physical link with the network      */
    /* ==================================================================== */
    Eth_WritePHY(DP83848_BMCR, PHY_BMCR_AUTONEG_EN | PHY_BMCR_RESTART_AN);
    for (timeout = 0; timeout < 0xFFFFF; timeout++) {
        phyStatus = Eth_ReadPHY(DP83848_BMSR);
        if ((phyStatus & PHY_BMSR_LINK_STAT) && (phyStatus & PHY_BMSR_AUTONEG_C)) break;
    }

    /* Return false if cable is unplugged or auto-negotiation fails */
    if (timeout == 0xFFFFF) return false;

    /* 7. Sync MAC to PHY Speed/Duplex */
    phyStatus = Eth_ReadPHY(DP83848_PHYSTS);
    if (phyStatus & PHY_STS_DUPLEX) {
        LPC_EMAC->MAC2 |= MAC2_FULL_DUP;
        LPC_EMAC->COMMAND |= CR_FULL_DUP;
        LPC_EMAC->IPGT = 0x0015;
    } else {
        LPC_EMAC->IPGT = 0x0012;
    }
    LPC_EMAC->SUPP = (phyStatus & PHY_STS_SPEED) ? 0 : (1 << 8);

    /* 8. Set MAC Address to 00:11:22:33:44:55 */
    LPC_EMAC->SA0 = 0x1100;
    LPC_EMAC->SA1 = 0x3322;
    LPC_EMAC->SA2 = 0x5544;

    /* 9. Initialize TX Descriptor Ring in AHB SRAM */
    EMAC_TxInit();

    /* 10. Accept Broadcast packets */
    LPC_EMAC->RXFILTERCTRL = RXFILT_CTRL_BROADCAST | RXFILT_CTRL_PERFECT;

    /* 11. Disable interrupts entirely to allow bare-metal polling */
    LPC_EMAC->INTENABLE = 0;
    LPC_EMAC->INTCLEAR = 0xFFFF;

    /* 12. Enable TX and RX */
    LPC_EMAC->COMMAND |= (CR_RX_EN | CR_TX_EN);
    LPC_EMAC->MAC1    |= MAC1_REC_EN;

    return true;
}
