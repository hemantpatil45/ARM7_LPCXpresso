#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "LPC24xx.h"
#include "glcd.h"
#include "system_init.h"
#include "ethernet.h"
#include "ethernet_rx.h"
   //
#define MAX_GLCD_CHARS 20
void Delay1Sec(void) {
    volatile uint32_t i;
    for(i = 0; i < 12000000; i++) { __asm("NOP"); }
}

int main(void) {
    bool link_status;
    uint8_t rx_buffer[1536];    // Sized to match ETH_RX_FRAG_SIZE - was 64,
                                // which overflowed on any real-size frame
    uint32_t rx_length = 0;
    uint32_t j;
    volatile uint32_t i;

    /* UART/Debugger safety delay */
    for(i = 0; i < 50000; i++) { __asm("NOP"); }

    PLL_Init();
    system_Init();

    GLCD_Init();
    GLCD_Clear();
    GLCD_RowWriteMargin(0, "RX BOARD: BOOTING...");

    link_status = Eth_Init();

    if (link_status) {
        GLCD_RowWriteMargin(2, "Link Status: UP   ");
    } else {
        GLCD_RowWriteMargin(2, "Link Status: FAIL ");
    }

    const uint8_t filter_pattern[] = "HELLO";

        while(1) {
            if (link_status) {
                /* Pass the correct number of arguments to your EMAC function */
                if (EMAC_ReceivePacket(rx_buffer, sizeof(rx_buffer), &rx_length)) {

                    /* 1. Filter: Check if payload starts with "HELLO" */
                    if (rx_length >= 19 && memcmp(&rx_buffer[14], filter_pattern, 5) == 0) {

                        char display_str[MAX_GLCD_CHARS + 1];

                        /* 2. Process: Copy data (now safely outside the loop) */
                        for(j = 0; j < MAX_GLCD_CHARS; j++) {
                            if ((14 + j) < rx_length && (rx_buffer[14 + j] >= 32 && rx_buffer[14 + j] <= 126)) {
                                display_str[j] = (char)rx_buffer[14 + j];
                            } else {
                                display_str[j] = ' ';
                            }
                        }

                        /* 3. Finalize: Null-terminate once per packet */
                        display_str[MAX_GLCD_CHARS] = '\0';

                        /* 4. Display: Write to GLCD once per packet */
                        GLCD_RowWriteMargin(4, display_str);
                    }
                }
            }
        }
}
