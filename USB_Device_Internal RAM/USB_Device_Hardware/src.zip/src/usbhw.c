#include "LPC24xx.h"
#include "usbhw.h"
#include "usbcore.h"
#include <stdbool.h>

volatile bool usb_event_detected = false;
volatile uint32_t last_disr = 0;
volatile uint32_t last_episr = 0;

void USB_WriteCmd(uint32_t cmd) {
    DEV_INT_CLR = 0x10;
    CMD_CODE = (cmd << 16) | 0x0500;
    while ((DEV_INT_STAT & 0x10) == 0);
    DEV_INT_CLR = 0x10;
}

void USB_WriteCmdData(uint32_t cmd, uint32_t data) {
    USB_WriteCmd(cmd);
    CMD_CODE = (data << 16) | 0x0100;
    while ((DEV_INT_STAT & 0x10) == 0);
    DEV_INT_CLR = 0x10;
}

uint32_t USB_ReadCmdData(uint32_t cmd) {
    DEV_INT_CLR = 0x10;
    DEV_INT_CLR = 0x20;
    CMD_CODE = (cmd << 16) | 0x0500;
    while ((DEV_INT_STAT & 0x10) == 0);
    DEV_INT_CLR = 0x10;

    CMD_CODE = (cmd << 16) | 0x0200;
    while ((DEV_INT_STAT & 0x20) == 0);

    uint32_t data = CMD_DATA;
    DEV_INT_CLR = 0x20;
    return data;
}

uint32_t EPAdrToPhys(uint32_t EPNum) {
    uint32_t dir = (EPNum & 0x80) ? 1 : 0;
    return ((EPNum & 0x0F) * 2) + dir;
}

void delay_s(uint32_t us) {
    for (volatile uint32_t i = 0; i < (us * 5); i++);
}

void USB_Init(void) {
    PCONP |= (1 << 31);
    USBCLKCFG = 5;

    OTG_CLK_CTRL = 0x12;
    while ((OTG_CLK_STAT & 0x12) != 0x12);

    delay_s(1000);

    PINSEL1 &= ~((3 << 26) | (3 << 28));
    PINSEL1 |=  ((1 << 26) | (1 << 28));
    PINSEL3 &= ~(3 << 28);
    PINSEL3 |=  (2 << 28);

    USB_ConfigEP(0x00, 64);
    USB_ConfigEP(0x80, 64);

    DEV_INT_CLR = 0x000000FF;
    EP_INT_CLR  = 0x00000003;

    EP_INT_EN = 0x00000003;
    DEV_INT_EN = (1 << 2) | (1 << 3) | (1 << 9);

    VICVectAddr22 = (uint32_t)USB_ISR;
    VICVectPriority22 = 2;
    VICIntEnable |= (1 << 22);
}

void USB_Connect(bool connect) {
    USB_WriteCmdData(CMD_SET_DEV_STAT, connect ? 1 : 0);
}

void USB_SetAddress(uint32_t adr) {
    USB_WriteCmdData(CMD_SET_ADDR, adr | 0x80);
}

void USB_Configure(bool configure) {
    USB_WriteCmdData(CMD_CFG_DEV, configure ? 1 : 0);
}

void USB_ConfigEP(uint32_t EPNum, uint32_t MaxPacketSize) {
    uint32_t phys_ep = EPAdrToPhys(EPNum);

    REALIZE_EP |= (1 << phys_ep);
    EP_INDEX = phys_ep;
    MAXPACKET_SIZE = MaxPacketSize;

    uint32_t timeout = 100000;
    while ((DEV_INT_STAT & (1 << 8)) == 0) {
        timeout--;
        if (timeout == 0) break;
    }
    DEV_INT_CLR = (1 << 8);
}

void USB_EnableEP(uint32_t EPNum) {
    USB_WriteCmdData(CMD_SET_EP_STAT + EPAdrToPhys(EPNum), 0);
}

void USB_DisableEP(uint32_t EPNum) {
    USB_WriteCmdData(CMD_SET_EP_STAT + EPAdrToPhys(EPNum), 1);
}

void USB_SetStallEP(uint32_t EPNum) {
    USB_WriteCmdData(CMD_SET_EP_STAT + EPAdrToPhys(EPNum), 1);
}

uint32_t USB_ReadEP(uint32_t EPNum, uint8_t *pData) {
    uint32_t phys_ep = EPAdrToPhys(EPNum);
    uint32_t logical_ep = EPNum & 0x0F;

    USB_WriteCmd(CMD_SEL_EP + phys_ep);
    USB_CTRL = (logical_ep << 2) | (1 << 0);

    uint32_t plength;
    do {
        plength = RX_PLENGTH;
    } while ((plength & 0x0800) == 0);

    uint32_t numBytes = plength & 0x3FF;

    for (uint32_t i = 0; i < (numBytes + 3) / 4; i++) {
        uint32_t word = RX_DATA;
        for (int b = 0; b < 4; b++) {
            uint32_t index = (i * 4) + b;
            if (index < numBytes) {
                pData[index] = (word >> (b * 8)) & 0xFF;
            }
        }
    }

    USB_CTRL = 0;
    USB_WriteCmd(CMD_SEL_EP + phys_ep);
    USB_WriteCmd(CMD_CLR_BUF);

    return numBytes;
}

uint32_t USB_WriteEP(uint32_t EPNum, uint8_t *pData, uint32_t cnt) {
    uint32_t phys_ep = EPAdrToPhys(EPNum);
    uint32_t logical_ep = EPNum & 0x0F;

    USB_CTRL = (logical_ep << 2) | (1 << 1);
    TX_PLENGTH = cnt;

    for (uint32_t i = 0; i < (cnt + 3) / 4; i++) {
        uint32_t word = 0;
        for (int b = 0; b < 4; b++) {
            uint32_t index = (i * 4) + b;
            if (index < cnt) {
                word |= ((uint32_t)pData[index]) << (b * 8);
            }
        }
        TX_DATA = word;
    }

    USB_CTRL = 0;
    USB_WriteCmd(CMD_SEL_EP + phys_ep);
    USB_WriteCmd(CMD_VALID_BUF);

    return cnt;
}

void USB_ISR(void) __attribute__((interrupt("IRQ")));

void USB_ISR(void) {
    uint32_t disr = DEV_INT_STAT;
    uint32_t episr = EP_INT_STAT;

    if (disr & (1 << 3)) {
        DEV_INT_CLR = (1 << 3);
        uint32_t dev_stat = USB_ReadCmdData(CMD_GET_DEV_STAT);
        if (dev_stat & (1 << 4)) {
            USB_WriteCmdData(CMD_SET_ADDR, 0x80);
            USB_ConfigEP(0x00, 64);
            USB_ConfigEP(0x80, 64);
        }
    }

    if (disr & (1 << 2)) {
        DEV_INT_CLR = (1 << 2);

        if (episr & (1 << 0)) {
            EP_INT_CLR = (1 << 0);
            USB_EndPoint0(0);
        }
        // EP1 Bulk IN (Host has finished receiving our data)
                if (episr & (1 << 3)) {
                    EP_INT_CLR = (1 << 3);
                    extern void BOT_Send_Next_Chunk(void);
                    BOT_Send_Next_Chunk(); // Automatically push the next 64 bytes!
                }
        if (episr & (1 << 3)) {
            EP_INT_CLR = (1 << 3);
        }
        if (episr & (1 << 4)) {
            EP_INT_CLR = (1 << 4);
            Process_Bulk_OUT();
        }
    }

    DEV_INT_CLR = disr;
    last_disr = disr;
    last_episr = episr;

    if ((disr & (1 << 2)) || (disr & (1 << 3)) || (disr & (1 << 9))) {
        usb_event_detected = true;
    }

    VICVectAddr = 0;
}
