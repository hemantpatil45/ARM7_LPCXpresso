#include <stdint.h>
#include <stdbool.h>
#include "LPC24xx.h"
#include "glcd.h"
#include "system_init.h"
#include "UART.h"

// Simple software delay loops using NOP instructions
void Delay1Sec(void) {
    volatile uint32_t i;
    for(i = 0; i < 12000000; i++) { __asm("NOP"); }
}

int main(void) {
    volatile uint32_t i;

    // Short delay to let hardware stabilize
    for(i = 0; i < 50000; i++) { __asm("NOP"); }

    // Initialize system clocks and peripherals
    PLL_Init();
    system_Init();

    // Setup display and UART
    GLCD_Init();
    GLCD_Clear();
    Timer0_Init();
    UART0_Init(UART0_BAUD);

    // Welcome screen on LCD
    GLCD_RowWriteMargin(0, "WELCOME TO AKADEMIKA");
    GLCD_RowWriteMargin(2, "       PL-ARM7      ");
    GLCD_RowWriteMargin(4, "UART TX ACTIVE      ");

    // Infinite transmission loop
    while(1) {                                      //[cite: 1]
        UART0_SendString("AT\r\n");
        Delay_ms(1000);
    }
}
