################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../src/cr_startup_lpc24.s 

C_SRCS += \
../src/crp.c \
../src/diskio.c \
../src/ff.c \
../src/glcd.c \
../src/main.c \
../src/sys_calls.c \
../src/system_init.c \
../src/uart0.c \
../src/usb_host_lpc2478.c \
../src/usb_host_td.c \
../src/usbhost_ms.c 

OBJS += \
./src/cr_startup_lpc24.o \
./src/crp.o \
./src/diskio.o \
./src/ff.o \
./src/glcd.o \
./src/main.o \
./src/sys_calls.o \
./src/system_init.o \
./src/uart0.o \
./src/usb_host_lpc2478.o \
./src/usb_host_td.o \
./src/usbhost_ms.o 

C_DEPS += \
./src/crp.d \
./src/diskio.d \
./src/ff.d \
./src/glcd.d \
./src/main.d \
./src/sys_calls.d \
./src/system_init.d \
./src/uart0.d \
./src/usb_host_lpc2478.d \
./src/usb_host_td.d \
./src/usbhost_ms.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.s
	@echo 'Building file: $<'
	@echo 'Invoking: MCU Assembler'
	arm-none-eabi-gcc -c -x assembler-with-cpp -DDEBUG -D__CODE_RED -D__REDLIB__ -g3 -mcpu=arm7tdmi -specs=redlib.specs -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -DDEBUG -D__CODE_RED -D__REDLIB__ -O0 -fno-common -g3 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -mcpu=arm7tdmi -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


