#include "usb_host_lpc2478.h"
#include "usbhost_ms.h"

volatile DWORD g_USBConnected = 0;

/* Hardware Initialization tailored to PL-ARM7 Ver 14.1 Schematic */
void USBHost_HardwareInit(void) {
    // 1. Power up the USB Peripheral Block
    PCONP |= (1UL << 31); // Set PCUSB bit

    // 2. Configure Pin Multiplexing for USB Port 2 (Sheet 1 & Sheet 2)
    // P0[12] -> USB_PPWR2 (Func 01)
    PINSEL0 = (PINSEL0 & ~(3UL << 24)) | (1UL << 24);

    // P0[13] -> USB_UP_LED2 (Func 01)
    PINSEL0 = (PINSEL0 & ~(3UL << 26)) | (1UL << 26);

    // P0[31] -> USB_D+2 (Func 01)
    PINSEL1 = (PINSEL1 & ~(3UL << 30)) | (1UL << 30);

    // P1[30] -> USB_PWRD2 (Func 01), P1[31] -> USB_OVRCR2# (Func 01)
    PINSEL3 = (PINSEL3 & ~(0xFUL << 28)) | (0x5UL << 28);

    // Disable internal pull-ups on Overcurrent & Power detect pins
    PINMODE3 = (PINMODE3 & ~(0xFUL << 28)) | (0xAUL << 28); // 10 = Disable pull-up/down

    // 3. Enable USB Clocks for Host Controller on Port 2
    // Bit 0: DEV_CLK, Bit 3: HOST_CLK, Bit 4: OTG_CLK
    OTG_CLK_CTRL = 0x19;
    while ((OTG_CLK_STAT & 0x19) != 0x19);

    UART0_Print("OTG_CLK_STAT = ");
    UART0_PrintHex(OTG_CLK_STAT);
    UART0_Print("\r\n");
    // 4. Configure Port 2 as Host
    OTG_STAT_CTRL |= (1<<0);
    UART0_Print("OTG_STAT_CTRL = ");
    UART0_PrintHex(OTG_STAT_CTRL);
    UART0_Print("\r\n");

    UART0_Print("PCONP = ");
    UART0_PrintHex(PCONP);
    UART0_Print("\r\n");
}

/* GCC Interrupt Handler for USB */
/* GCC Interrupt Handler for USB */
void __attribute__((interrupt("IRQ"))) USB_IRQHandler(void) {
    DWORD int_stat = HC_INT_STAT;

    // Root Hub Status Change (Device Connect / Disconnect)
    if (int_stat & (1UL << 6)) {
        if (HC_RH_PORT_STAT2 & 0x01) { // Device connected on Port 2
            g_USBConnected = 1;
        } else {
            g_USBConnected = 0;
        }
    }

    // ========================================================
    // CRITICAL FIX: Clear ALL pending interrupts that fired.
    // Writing 1s to the flags that are set will clear them.
    // ========================================================
    HC_INT_STAT = int_stat;

    // Acknowledge interrupt in Vectored Interrupt Controller (VIC)
    VICVectAddr = 0;
}

/* Initialize OHCI Controller for Port 2 */
DWORD USBHost_OHCIInit(void) {
    // Controller Software Reset
    HC_CONTROL = 0;
    HC_CMD_STAT = 0x01; // HostControllerReset
    while (HC_CMD_STAT & 0x01);
    UART0_Print("HC_REVISION = ");
    UART0_PrintHex(HC_REVISION);
    UART0_Print("\r\n");

    UART0_Print("HC_CONTROL after RESET = ");
    UART0_PrintHex(HC_CONTROL);
    UART0_Print("\r\n");

    UART0_Print("HC_CMD_STAT after RESET = ");
    UART0_PrintHex(HC_CMD_STAT);
    UART0_Print("\r\n");
    // Verify OHCI Revision (Must be 1.0 / 0x10)
    if ((HC_REVISION & 0xFF) != 0x10) {
        return USB_HOST_ERR;
    }

    // Disable all OHCI interrupts during setup
    HC_INT_DIS = 0x8000007F;

    // Set HCCA Memory Address in USB SRAM
    HC_HCCA = USB_OHCI_BASE_ADDR;
    UART0_Print("HC_HCCA = ");
    UART0_PrintHex(HC_HCCA);
    UART0_Print("\r\n");
    // Control/Bulk ED lists initialized to NULL
    HC_CTRL_HEAD_ED = 0;
    HC_BULK_HEAD_ED = 0;

    // Set Frame Interval parameters (Standard 1ms frame time)
    HC_FM_INTERVAL = (FM_INTERVAL_FSMPS << 16) | FM_INTERVAL_FI;
    HC_PERIOD_START = PERIODIC_START;
    HC_LS_THRHLD    = LS_THRESHOLD;

    // Set Operational State
    /* Put controller into USB Reset state first */
    HC_CONTROL = (0x02 << 6) | (1 << 5) | (1 << 4) | (1 << 3) | 0x03;

    UART0_Print("HC_CONTROL = ");
    UART0_PrintHex(HC_CONTROL);
    UART0_Print("\r\n");


    for (volatile int i = 0; i < 10000; i++);

    UART0_Print("HC_CONTROL after WRITE = ");
    UART0_PrintHex(HC_CONTROL);
    UART0_Print("\r\n");

    // Configure Root Hub Descriptor A (Port 2 power managed individually)
    HC_RH_DESCA = (PWRON_TO_PWRGOOD << 24) | 0x0B01;
    HC_RH_DESCB = 0x0000;

    // Enable Global Power to Ports (Powers LM3526-L via USB_PPWR2)
    HC_RH_STAT = (1UL << 16); // SetGlobalPower
    delay_ms(120);
    // Configure VIC Interrupt Vector (USB Int Slot 22)
    VICVectAddr22 = (unsigned long)USB_IRQHandler;
    VICVectPriority22 = 1;
    VICIntEnable = (1UL << 22);

    // Enable Host Interrupts
    HC_INT_EN = 0x80000042; // MIE + RootHubStatusChange + WritebackDone

    return USB_HOST_OK;
}

void USBHost_ResetPort(void) {
	HC_RH_PORT_STAT2 = (1UL << 4);

	while (!(HC_RH_PORT_STAT2 & (1UL << 20)));

	HC_RH_PORT_STAT2 = (1UL << 20);

	delay_ms(50);          // <------ ADD THIS

	HC_RH_PORT_STAT2 = (1UL << 1);

	delay_ms(20);          // <------ ADD THIS
	UART0_Print("HC_FM_INTERVAL = ");
	UART0_PrintHex(HC_FM_INTERVAL);
	UART0_Print("\r\n");

	UART0_Print("HC_RH_DESCA = ");
	UART0_PrintHex(HC_RH_DESCA);
	UART0_Print("\r\n");
}
